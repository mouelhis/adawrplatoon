
from test_utils import *
import sys

if not local(r'core/random/test000', r''):
    fail()

