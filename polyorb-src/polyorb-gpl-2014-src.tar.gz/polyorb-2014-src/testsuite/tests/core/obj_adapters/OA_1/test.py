
from test_utils import *
import sys

if not local(r'core/obj_adapters/test001', r''):
    fail()

