
from test_utils import *
import sys

if not local(r'core/dynamic_dict/test000', r''):
    fail()

