
from test_utils import *
import sys

if not local(r'core/tasking/test002', r''):
    fail()

