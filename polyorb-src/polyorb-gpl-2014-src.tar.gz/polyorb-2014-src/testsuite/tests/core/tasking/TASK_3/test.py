
from test_utils import *
import sys

if not local(r'core/tasking/test003', r''):
    fail()

