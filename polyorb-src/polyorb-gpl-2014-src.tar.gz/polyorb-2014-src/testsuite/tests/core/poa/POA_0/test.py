
from test_utils import *
import sys

if not local(r'core/poa/test000', r''):
    fail()

