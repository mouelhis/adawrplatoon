
from test_utils import *
import sys

if not local(r'core/chained_lists/test000', r''):
    fail()

