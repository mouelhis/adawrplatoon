
from test_utils import *
import sys

if not local(r'core/fixed_point/test000', r''):
    fail()

