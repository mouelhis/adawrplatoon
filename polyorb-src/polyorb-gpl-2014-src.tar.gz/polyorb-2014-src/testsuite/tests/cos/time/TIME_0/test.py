
from test_utils import *
import sys

if not local(r'corba/cos/time/test_time', r''):
    fail()

