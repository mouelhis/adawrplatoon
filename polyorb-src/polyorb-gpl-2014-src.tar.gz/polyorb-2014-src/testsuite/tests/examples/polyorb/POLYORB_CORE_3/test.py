
from test_utils import *
import sys

if not local(r'../examples/polyorb/polyorb-test-thread_pool_poa', r''):
    fail()

