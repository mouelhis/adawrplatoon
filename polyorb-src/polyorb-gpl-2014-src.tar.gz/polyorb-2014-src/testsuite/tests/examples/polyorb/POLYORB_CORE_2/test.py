
from test_utils import *
import sys

if not local(r'../examples/polyorb/polyorb-test-thread_pool', r''):
    fail()

