
from test_utils import *
import sys

if not local(r'../examples/polyorb/polyorb-test-no_tasking', r''):
    fail()

