
from test_utils import *
import sys

if not local(r'corba/location_forwarding/test000/test000', r''):
    fail()

