
from test_utils import *
import sys

if not local(r'corba/shutdown/test001_client', r''):
    fail()

