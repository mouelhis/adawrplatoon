
from test_utils import *
import sys

if not local(r'corba/orb_init/test000', r''):
    fail()

