
from test_utils import *
import sys

if not local(r'corba/rtcorba/rtorb/test000', r''):
    fail()

