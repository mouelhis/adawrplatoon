
from test_utils import *
import sys

if not local(r'corba/portableserver/test002', r''):
    fail()

