
from test_utils import *
import sys

if not local(r'corba/portableserver/test001', r''):
    fail()

