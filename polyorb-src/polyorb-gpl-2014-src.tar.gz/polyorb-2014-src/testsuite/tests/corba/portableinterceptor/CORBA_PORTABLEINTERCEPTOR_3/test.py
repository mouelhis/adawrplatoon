
from test_utils import *
import sys

if not local(r'corba/portableinterceptor/test003/test003', r''):
    fail()

