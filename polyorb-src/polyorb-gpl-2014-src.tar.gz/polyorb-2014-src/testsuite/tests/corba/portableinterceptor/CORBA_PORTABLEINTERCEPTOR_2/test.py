
from test_utils import *
import sys

if not local(r'corba/portableinterceptor/test002/test002', r''):
    fail()

