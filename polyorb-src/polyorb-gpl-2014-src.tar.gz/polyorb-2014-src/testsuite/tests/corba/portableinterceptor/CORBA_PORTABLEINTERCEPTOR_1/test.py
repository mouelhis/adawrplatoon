
from test_utils import *
import sys

if not local(r'corba/portableinterceptor/test001/test001', r''):
    fail()

