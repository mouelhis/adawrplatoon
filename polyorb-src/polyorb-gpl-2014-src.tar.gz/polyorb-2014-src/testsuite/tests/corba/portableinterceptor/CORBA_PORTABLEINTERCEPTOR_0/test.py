
from test_utils import *
import sys

if not local(r'corba/portableinterceptor/test000/test000', r''):
    fail()

