
from test_utils import *
import sys

if not local(r'corba/harness/local', r''):
    fail()

