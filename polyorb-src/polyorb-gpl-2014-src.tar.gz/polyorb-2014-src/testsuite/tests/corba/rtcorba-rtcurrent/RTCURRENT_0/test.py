
from test_utils import *
import sys

if not local(r'corba/rtcorba/rtcurrent/rtcurrent', r''):
    fail()

