
from test_utils import *
import sys

if not local(r'corba/rtcorba/rtpoa/test000', r''):
    fail()

