#! /bin/sh

po_gnatdist -Premote_json -gnat05 echo_json
